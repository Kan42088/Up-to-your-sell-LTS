<?php
/**
 * @package Up_To_Your_Sell
 * @version 1.2.0
 */
/*
Plugin Name: Up to your sell
Plugin URI: https://www.google.com/
Description: Up sell but it in another version
Author: Bito
Version: 1.2.0
Author URI: https://www.google.com/
*/

//regist for new table in db when activels
class UTYSOption {
    // Properties
    public $id;
    public $number_of_product;
    public $percent_of_discount;
  
    //C
    function __construct($id,$number_of_product, $percent_of_discount) {
        $this->id =$id;
        $this->number_of_product = $number_of_product; 
        $this->percent_of_discount = $percent_of_discount; 
      }
    // Methods
    function set_id($id) {
        $this->id = $id;
      }
      function get_id() {
        return $this->id;
      }
    function set_number_of_product($number_of_product) {
      $this->number_of_product = $number_of_product;
    }
    function get_number_of_product() {
      return $this->number_of_product;
    }

    function set_percent_of_discount($percent_of_discount) {
        $this->percent_of_discount = $percent_of_discount;
      }
      function get_percent_of_discount() {
        return $this->percent_of_discount;
      }
  }

if(!function_exists("create_the_custom_table_for_utys")){
        function create_the_custom_table_for_utys() {
                global $wpdb;
                $charset_collate = $wpdb->get_charset_collate();
                    
                $table_name = $wpdb->prefix . 'UpToYourSell';
            
                $sql = "CREATE TABLE " . $table_name . " (
                    id int(11) NOT NULL AUTO_INCREMENT,
                    number_of_product int(11),
                    percent_of_discount int(11),
                    PRIMARY KEY  (id)
                ) $charset_collate;";
             
                require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
                dbDelta($sql);
        }  
        
}
register_activation_hook(__FILE__, 'create_the_custom_table_for_utys');


// Call extra_post_info_menu function to load plugin menu in dashboard 
add_action('admin_menu', 'up_to_your_sell_menu');
// Create WordPress admin menu 
if (!function_exists("up_to_your_sell_menu")) {
    function up_to_your_sell_menu()
    {
        $page_title = 'Up to your sell setting page';
        $menu_title = 'Up to your sell';
        $capability = 'manage_options';
        $menu_slug  = 'up-to-your-sell';
        $function   = 'up_to_your_sell_page';
        $icon_url   = 'dashicons-tickets-alt';
        $position   = 50;
        add_menu_page($page_title, $menu_title, $capability, $menu_slug, $function, $icon_url, $position);
        // Call update_extra_post_info function to update database   
        //add_action('admin_init', 'update_trigger_order_options');
    }
}

if (!function_exists("up_to_your_sell_page")) {
    function up_to_your_sell_page()
    {
        ?>
            <h1>Trang cài đặt Up sell:</h1>
            <table class="form-table">
                    <tr>
                        <h3>Cài đặt up sell:</h3>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Thêm khuyến mãi theo số sản phẩm:</th>
                        <td>
                            <input type="password" name="utys_number_of_product" value="" id="utys_nop">
                            <input type="password" name="utys_percent_of_discount" value="" id="utys_pod">
                        </td>
                    </tr>
            </table>
        <?php

    }

}

//get cart and make the discount
add_action( 'woocommerce_cart_calculate_fees', 'custom_fee_based_on_cart_total', 10, 1 );
function custom_fee_based_on_cart_total( $cart ) {

    //if ( is_admin() && ! defined( 'DOING_AJAX' ) ) return;
    $listOptions = array(
        new UTYSOption(1,2,10),
        new UTYSOption(1,5,15),
        new UTYSOption(1,20,25),
        new UTYSOption(1,10,20)
        );
    
    usort($listOptions, function($a, $b) {
        if ($a->get_number_of_product() == $b->get_number_of_product()) {
          return 0;
        }
      return ($a->get_number_of_product() < $b->get_number_of_product()) ? -1 : 1;
    });

    //get tatal of product
    $totalProduct = 0;
    foreach ( WC()->cart->get_cart() as $cart_item ) {
     $totalProduct += 1;
    }
    
    //get the percent
    $percent = 0;

    foreach($listOptions as $opt){
        if($totalProduct >= $opt->get_number_of_product()){
            $percent = $opt->get_percent_of_discount();
        }
    }




    // The cart total
    $cart_total = $cart->cart_contents_total; 
    // The conditional Calculation
    $fee = -$cart_total * $percent / 100 ;
    if ( $fee != 0 ) 
        $cart->add_fee( __( "You get ". $percent ."% discount !", "woocommerce" ), $fee, false );
}
// register jquery and style on initialization
add_action('init', 'register_script');
function register_script() {
    //wp_register_script( 'custom_jquery', plugins_url('/js/custom-jquery.js', __FILE__), array('jquery'), '2.5.1' );

    wp_register_style( 'new_style', plugins_url('/style_utys.css', __FILE__), false, '1.0.0', 'all');
}

// use the registered jquery and style above
add_action('wp_enqueue_scripts', 'enqueue_style');

function enqueue_style(){
   //wp_enqueue_script('custom_jquery');

   wp_enqueue_style( 'new_style' );
}
add_action( 'woocommerce_after_add_to_cart_form', 'add_content_after_addtocart_button_func' );


/*
 * Content below "Add to cart" Button.
 */
function add_content_after_addtocart_button_func() {

        // Echo content.
        ?><div class="upsell-bmsm-heading">
        <div class="upsellboxes">
            <div class="upsellbox1">
                <svg height="512pt" viewBox="0 0 512 512" width="512pt" xmlns="http://www.w3.org/2000/svg">
                    <path
                        d="m416.667969 0h-321.335938c-52.566406 0-95.332031 42.765625-95.332031 95.332031v264.53125c0 52.566407 42.765625 95.332031 95.332031 95.332031h97.648438l52.414062 52.410157c2.925781 2.929687 6.765625 4.394531 10.605469 4.394531 3.835938 0 7.675781-1.464844 10.605469-4.394531l52.410156-52.410157h97.648437c52.566407 0 95.332032-42.765624 95.332032-95.332031v-264.53125c.003906-52.566406-42.761719-95.332031-95.328125-95.332031zm65.332031 359.863281c0 36.023438-29.308594 65.332031-65.332031 65.332031h-103.863281c-3.976563 0-7.792969 1.582032-10.605469 4.394532l-46.199219 46.195312-46.199219-46.195312c-2.8125-2.816406-6.625-4.394532-10.605469-4.394532h-103.863281c-36.023437 0-65.332031-29.308593-65.332031-65.332031v-264.53125c0-36.023437 29.308594-65.332031 65.332031-65.332031h321.335938c36.023437 0 65.332031 29.308594 65.332031 65.332031zm0 0">
                    </path>
                    <path
                        d="m137.859375 134.949219h-50.558594c-2.070312 0-3.75 1.679687-3.75 3.75v10.074219c0 2.070312 1.679688 3.75 3.75 3.75h16.023438v51.378906c0 2.074218 1.679687 3.75 3.75 3.75h11.011719c2.070312 0 3.75-1.675782 3.75-3.75v-51.378906h16.023437c2.070313 0 3.75-1.679688 3.75-3.75v-10.074219c0-2.070313-1.679687-3.75-3.75-3.75zm0 0">
                    </path>
                    <path
                        d="m160.804688 207.652344c2.070312 0 3.75-1.675782 3.75-3.75v-22.929688h24.871093v22.929688c0 2.074218 1.679688 3.75 3.75 3.75h11.003907c2.074218 0 3.75-1.675782 3.75-3.75v-65.203125c0-2.070313-1.675782-3.75-3.75-3.75h-11.003907c-2.070312 0-3.75 1.679687-3.75 3.75v24.515625h-24.871093v-24.515625c0-2.070313-1.679688-3.75-3.75-3.75h-11.003907c-2.074219 0-3.75 1.679687-3.75 3.75v65.203125c0 2.074218 1.675781 3.75 3.75 3.75zm0 0">
                    </path>
                    <path
                        d="m257.144531 137.1875c-.597656-1.359375-1.945312-2.238281-3.429687-2.238281h-11.753906c-1.484376 0-2.832032.878906-3.433594 2.238281l-28.730469 65.207031c-.511719 1.15625-.402344 2.496094.292969 3.558594.6875 1.0625 1.871094 1.703125 3.140625 1.703125h11.753906c1.484375 0 2.832031-.878906 3.429687-2.242188l5.546876-12.589843h27.753906l5.546875 12.589843c.597656 1.363282 1.945312 2.242188 3.429687 2.242188h11.753906.023438c2.070312 0 3.75-1.679688 3.75-3.75 0-.675781-.179688-1.304688-.488281-1.851562zm-3.210937 37.964844h-12.191406l6.097656-13.820313zm0 0">
                    </path>
                    <path
                        d="m351.382812 134.949219h-11.011718c-2.070313 0-3.75 1.679687-3.75 3.75v37.765625l-31.160156-40.066406c-.707032-.914063-1.800782-1.449219-2.957032-1.449219h-11.011718c-2.070313 0-3.75 1.679687-3.75 3.75v65.207031c0 2.070312 1.679687 3.75 3.75 3.75h11.011718c2.070313 0 3.75-1.679688 3.75-3.75v-36.632812l30.222656 38.929687c.710938.917969 1.804688 1.453125 2.960938 1.453125h11.941406c2.070313 0 3.75-1.679688 3.75-3.75v-65.207031c.003906-2.070313-1.675781-3.75-3.746094-3.75zm0 0">
                    </path>
                    <path
                        d="m402.949219 167.523438 24.140625-26.289063c1.007812-1.09375 1.269531-2.683594.671875-4.042969-.601563-1.363281-1.945313-2.242187-3.433594-2.242187h-13.992187c-1.039063 0-2.027344.429687-2.734376 1.183593l-23.367187 24.898438v-22.332031c0-2.070313-1.679687-3.75-3.75-3.75h-11.007813c-2.070312 0-3.75 1.679687-3.75 3.75v65.203125c0 2.074218 1.679688 3.75 3.75 3.75h11.007813c2.070313 0 3.75-1.675782 3.75-3.75v-16.808594l5.476563-5.90625 18.941406 24.984375c.710937.933594 1.816406 1.480469 2.988281 1.480469h13.058594c1.410156 0 2.703125-.789063 3.34375-2.042969.640625-1.257813.523437-2.765625-.304688-3.90625zm0 0">
                    </path>
                    <path
                        d="m214.449219 248.808594c-.660157-1.1875-1.914063-1.921875-3.269531-1.921875h-12.035157c-1.316406 0-2.535156.691406-3.214843 1.820312l-14.601563 24.3125-14.601563-24.3125c-.679687-1.128906-1.898437-1.820312-3.214843-1.820312h-12.035157c-1.359374 0-2.609374.734375-3.273437 1.921875-.664063 1.183594-.632813 2.636718.078125 3.792968l23.699219 38.554688v24.6875c0 2.070312 1.679687 3.75 3.75 3.75h11.195312c2.070313 0 3.75-1.679688 3.75-3.75v-24.6875l23.695313-38.554688c.714844-1.160156.742187-2.609374.078125-3.792968zm0 0">
                    </path>
                    <path
                        d="m247.464844 245.304688c-10.671875 0-19.777344 3.605468-27.0625 10.71875-7.308594 7.140624-11.015625 16.140624-11.015625 26.75 0 10.613281 3.707031 19.613281 11.015625 26.75 7.289062 7.117187 16.394531 10.722656 27.0625 10.722656 10.667968 0 19.769531-3.605469 27.058594-10.722656 7.3125-7.136719 11.019531-16.140626 11.019531-26.75 0-10.609376-3.707031-19.609376-11.019531-26.75-7.285157-7.113282-16.386719-10.71875-27.058594-10.71875zm0 57.367187c-5.457032 0-9.929688-1.886719-13.675782-5.761719-3.777343-3.910156-5.613281-8.53125-5.613281-14.136718 0-5.601563 1.835938-10.226563 5.613281-14.136719 3.746094-3.875 8.21875-5.761719 13.675782-5.761719 5.457031 0 9.929687 1.886719 13.671875 5.757812 3.78125 3.917969 5.621093 8.542969 5.621093 14.140626 0 5.601562-1.839843 10.226562-5.621093 14.136718-3.742188 3.875-8.210938 5.761719-13.671875 5.761719zm0 0">
                    </path>
                    <path
                        d="m350.074219 246.886719h-11.007813c-2.070312 0-3.75 1.679687-3.75 3.75v36.101562c0 5.023438-1.203125 8.972657-3.574218 11.738281-2.257813 2.636719-5.292969 3.917969-9.28125 3.917969-3.984376 0-7.019532-1.28125-9.277344-3.917969-2.371094-2.765624-3.574219-6.714843-3.574219-11.738281v-36.101562c0-2.070313-1.679687-3.75-3.75-3.75h-11.007813c-2.074218 0-3.75 1.679687-3.75 3.75v36.566406c0 10.394531 2.980469 18.589844 8.863282 24.363281 5.859375 5.757813 13.429687 8.679688 22.496094 8.679688 9.066406 0 16.636718-2.921875 22.5-8.679688 5.882812-5.773437 8.863281-13.96875 8.863281-24.363281v-36.566406c0-2.070313-1.679688-3.75-3.75-3.75zm0 0">
                    </path>
                </svg>
            </div>
            <div class="upsellbox2">
                <div class="upsellbmsm-title">Buy More Save More with <?php echo get_bloginfo( 'name' ); ?>!</div>
                <div class="upsellbmsm-text">It’s time to give thanks for all the little things.</div>
            </div>
        </div>
    </div>
    <!-- Buy More Save More Items -->
    <ul class="upsell-bmsm-items upsell-has-button" data-discount_type="items" data-style="style1">
        <?php 
          $listOptions = array(
            new UTYSOption(1,2,10),
            new UTYSOption(1,5,15),
            new UTYSOption(1,20,25),
            new UTYSOption(1,10,20)
            );
        
        usort($listOptions, function($a, $b) {
            if ($a->get_number_of_product() == $b->get_number_of_product()) {
              return 0;
            }
          return ($a->get_number_of_product() < $b->get_number_of_product()) ? -1 : 1;
        });

        foreach($listOptions as $opt){?>
        <li>
            <div class="upsell-bmsm-item-text">
                <span class="upsell-bmsm-item-label"><?php echo($opt->get_percent_of_discount()); ?>% OFF</span>
                <span class="upsell-bmsm-item-title-wrp">
                    <span class="upsell-bmsm-item-title"> <?php echo($opt->get_number_of_product()); ?> items get 
                    <span class="upsell-bmsm-item-label2"><?php echo($opt->get_percent_of_discount()); ?>% OFF
                    </span></span> on cart total
                </span>
                <span class="upsell-bmsm-items-add" data-quantity="2">Buy more!</span>
            </div>
        </li>
        <?php } ?>
        
    </ul>
    <?php

}